#!/usr/bin/env python3
"""Package a verified pengcheng website with a reproducible file hash list."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import zipfile

from verify_site import verify_static

PRIVATE_PARTS = {"verification", "__pycache__", "inputs", "input", ".git", ".venv"}
PRIVATE_NAMES = {"audit.json", "plan.json", "contact-sheet.jpg", ".DS_Store"}


def package(root: Path, target: Path) -> Path:
    root, target = root.resolve(), target.resolve()
    result = verify_static(root)
    if not result["static"]:
        raise ValueError("网页静态验收失败：" + "；".join(result["errors"]))
    if target.exists():
        raise FileExistsError(f"交付包已存在，不覆盖：{target}")
    if target.is_relative_to(root):
        raise ValueError("交付包必须放在网页目录之外")
    target.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(target, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=7) as bundle:
        for path in sorted(root.rglob("*")):
            relative = path.relative_to(root)
            if (path.is_file() and not path.is_symlink()
                    and not (set(relative.parts) & PRIVATE_PARTS)
                    and path.name not in PRIVATE_NAMES
                    and not any(part.startswith(".") for part in relative.parts)):
                bundle.write(path, relative.as_posix())
    with zipfile.ZipFile(target) as bundle:
        bad = bundle.testzip()
        if bad:
            target.unlink()
            raise ValueError(f"ZIP 校验失败：{bad}")
    digest = hashlib.sha256(target.read_bytes()).hexdigest()
    (target.parent / f"{target.name}.sha256").write_text(f"{digest}  {target.name}\n", encoding="utf-8")
    return target


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("site", type=Path)
    parser.add_argument("zip", type=Path)
    args = parser.parse_args()
    try:
        result = package(args.site, args.zip)
    except (OSError, ValueError) as exc:
        parser.exit(2, f"打包失败：{exc}\n")
    print(f"网页交付包：{result}")


if __name__ == "__main__":
    main()
