#!/usr/bin/env python3
"""Compose a quiet, seamless instrumental loop from generated tones."""

from __future__ import annotations

import argparse
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
import wave

import numpy as np

RATE = 48_000
SOURCE_SECONDS = 52
OVERLAP_SECONDS = 4
MOODS = {
    "stone": [110.00, 130.81, 146.83, 196.00, 220.00],
    "water": [146.83, 164.81, 185.00, 220.00, 277.18],
    "garden": [130.81, 146.83, 164.81, 196.00, 220.00],
    "open-air": [110.00, 123.47, 146.83, 164.81, 196.00],
}


def compose(mood: str, seed: int) -> np.ndarray:
    notes = MOODS[mood]
    length = RATE * SOURCE_SECONDS
    time = np.arange(length, dtype=np.float32) / RATE
    root = notes[0] / 2
    breath = .79 + .11 * np.sin(2 * np.pi * .031 * time) + .08 * np.sin(2 * np.pi * .017 * time + 1.3)
    body = (.38 * np.sin(2 * np.pi * root * time)
            + .22 * np.sin(2 * np.pi * notes[0] * time + .7)
            + .10 * np.sin(2 * np.pi * notes[2] * time + 1.4)) * breath
    score = body.astype(np.float32) * .045

    rng = np.random.default_rng(seed)
    noise = rng.standard_normal(length).astype(np.float32)
    window = 1100
    cumulative = np.cumsum(noise, dtype=np.float64)
    air = np.empty(length, dtype=np.float32)
    air[:window] = cumulative[:window] / np.arange(1, window + 1)
    air[window:] = (cumulative[window:] - cumulative[:-window]) / window
    air /= max(float(np.std(air)), .001)
    score += air * (.0028 if mood == "water" else .0018)

    for index, when in enumerate((2, 9, 16, 24, 32, 39, 47)):
        start, size = when * RATE, min(8 * RATE, length - when * RATE)
        local = np.arange(size, dtype=np.float32) / RATE
        note = notes[(index * 2 + (seed % 3)) % len(notes)]
        envelope = (1 - np.exp(-local * 28)) * np.exp(-local / 2.25)
        tone = (np.sin(2 * np.pi * note * local)
                + .20 * np.sin(2 * np.pi * note * 2.01 * local + .5)
                + .06 * np.sin(2 * np.pi * note * 3.98 * local + 1.2))
        score[start:start + size] += .043 * envelope * tone

    # Overlap the ending with the beginning. The output's first and last samples
    # come from the same point in the source, so HTML audio can repeat quietly.
    overlap = OVERLAP_SECONDS * RATE
    u = np.arange(overlap, dtype=np.float32)[:, None] / overlap
    blend = (1 - np.cos(np.pi * u)) / 2
    stereo = np.stack((score * (1 + .035 * np.sin(.14 * time)),
                       score * (1 + .035 * np.sin(.14 * time + 1.5))), axis=1)
    loop = np.concatenate((stereo[-overlap:] * (1 - blend) + stereo[:overlap] * blend,
                           stereo[overlap:-overlap]), axis=0)
    peak = max(float(np.max(np.abs(loop))), .001)
    return np.clip(loop * min(.31 / peak, 5), -.95, .95)


def write_wave(path: Path, data: np.ndarray):
    with wave.open(str(path), "wb") as file:
        file.setnchannels(2)
        file.setsampwidth(2)
        file.setframerate(RATE)
        file.writeframes((data * 32767).astype("<i2").tobytes())


def create(destination: Path, mood: str = "garden", seed: int = 20261008) -> Path:
    if mood not in MOODS:
        raise ValueError(f"mood 应为 {', '.join(MOODS)}")
    destination = destination.expanduser().resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    data = compose(mood, seed)
    with tempfile.TemporaryDirectory(prefix=".music-", dir=destination.parent) as workspace:
        wave_path = Path(workspace) / "loop.wav"
        write_wave(wave_path, data)
        if destination.suffix.lower() == ".mp3" and shutil.which("ffmpeg"):
            encoded = Path(workspace) / "loop.mp3"
            subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(wave_path),
                            "-codec:a", "libmp3lame", "-q:a", "3", str(encoded)], check=True)
            os.replace(encoded, destination)
        else:
            if destination.suffix.lower() != ".wav":
                destination = destination.with_suffix(".wav")
            os.replace(wave_path, destination)
    return destination


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="输出 .mp3；无 FFmpeg 时保存为 .wav")
    parser.add_argument("--mood", choices=MOODS, default="garden")
    parser.add_argument("--seed", type=int, default=20261008)
    args = parser.parse_args()
    created = create(args.output, args.mood, args.seed)
    print(f"原创循环配乐：{created} · 48 秒 · {args.mood}")


if __name__ == "__main__":
    main()
