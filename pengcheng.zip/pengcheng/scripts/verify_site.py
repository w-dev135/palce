#!/usr/bin/env python3
"""Check a pengcheng site on disk and, when available, in desktop and phone browsers."""

from __future__ import annotations

import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import io
import json
from pathlib import Path
import re
import threading
from urllib.parse import urlparse

from PIL import Image, ImageChops, ImageStat

OLD_MARKS = ("wat" + "tter", "wat" + "ter.cn", "wtt" + "-code-animation-studio", "t.co/")
REQUIRED = ("index.html", "style.css", "app.js", "site.json", "vendor/three.min.js", "vendor/LICENSE", "ASSETS.md")


def verify_static(root: Path) -> dict:
    errors = []
    for relative in REQUIRED:
        if not (root / relative).is_file():
            errors.append(f"缺少 {relative}")
    if errors:
        return {"static": False, "errors": errors}
    site = json.loads((root / "site.json").read_text(encoding="utf-8"))
    if site.get("schema") != "pengcheng/site-v1":
        errors.append("site.json 版本不正确")
    chapters = site.get("chapters", [])
    if len(chapters) != 4:
        errors.append("应有恰好四幕")
    used = set()
    for item in chapters:
        image = item.get("image", "")
        if not image.startswith("assets/") or ".." in Path(image).parts:
            errors.append(f"无效照片路径：{image}")
            continue
        used.add(image)
        try:
            with Image.open(root / image) as picture:
                picture.verify()
        except (OSError, ValueError):
            errors.append(f"照片无法打开：{image}")
        for key in ("labelZh", "labelEn", "quoteZh", "quoteEn"):
            if not item.get(key):
                errors.append(f"{item.get('id', '?')} 缺少 {key}")
    credits = {item.get("image") for item in site.get("credits", [])}
    if used != credits:
        errors.append("章节照片与署名列表不一致")
    audio = site.get("audioFile")
    if audio:
        audio_path = Path(audio)
        if audio_path.is_absolute() or ".." in audio_path.parts or not audio.startswith("assets/"):
            errors.append("音频路径必须指向本地 assets/ 文件")
        elif not (root / audio_path).is_file():
            errors.append("音频文件不存在")
    for relative in ("index.html", "style.css", "app.js", "site.json", "ASSETS.md", "RUN.md"):
        path = root / relative
        if path.is_file() and any(mark in path.read_text(encoding="utf-8").lower() for mark in OLD_MARKS):
            errors.append(f"{relative} 含旧推广标识")
    if re.search(r"https?://(?!127\.0\.0\.1|localhost)", (root / "index.html").read_text(encoding="utf-8")):
        errors.append("首页含外部加载地址")
    return {"static": not errors, "chapters": len(chapters), "images": len(used), "credits": len(credits),
            "unverifiedRights": sum(1 for c in site.get("credits", []) if "待核实" in c.get("author", "") or "待核实" in c.get("license", "") or "待原页复核" in c.get("author", "") or "待原页复核" in c.get("license", "")),
            "errors": errors}


def verify_browser(root: Path, screenshots: Path | None) -> dict:
    from playwright.sync_api import sync_playwright

    chapter_interactions = [row.get("interaction") for row in json.loads((root / "site.json").read_text(encoding="utf-8"))["chapters"]]
    handler = partial(SimpleHTTPRequestHandler, directory=str(root))
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    base = f"http://127.0.0.1:{server.server_port}"
    results = []
    try:
        with sync_playwright() as playwright:
            chrome = Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome")
            kwargs = {"headless": True, "args": ["--enable-webgl", "--use-gl=angle", "--disable-gpu-sandbox"]}
            if chrome.is_file():
                kwargs["executable_path"] = str(chrome)
            browser = playwright.chromium.launch(**kwargs)
            for name, width, height, mobile in (("desktop", 1440, 900, False), ("mobile", 390, 844, True)):
                page = browser.new_page(viewport={"width": width, "height": height},
                                        is_mobile=mobile, has_touch=mobile)
                errors, outside = [], []
                page.on("pageerror", lambda exc: errors.append(str(exc)))
                page.on("request", lambda request: outside.append(request.url) if urlparse(request.url).netloc != urlparse(base).netloc else None)
                page.goto(base, wait_until="networkidle")
                page.wait_for_function("document.querySelector('#loading').classList.contains('fade')", timeout=30000)
                page.wait_for_timeout(800)
                if screenshots:
                    screenshots.mkdir(parents=True, exist_ok=True)
                    page.screenshot(path=str(screenshots / f"{name}-intro.png"))
                assert page.locator("#scene canvas").count() == 1, "三维画布未加载"
                assert page.locator("#fallback").is_hidden(), "浏览器显示三维降级页面"
                page.locator("#enterBtn").click()
                page.wait_for_timeout(2400)
                assert page.locator("#experience").is_visible(), "无法进入场所"
                chapter_buttons = page.locator("#modeList .mode")
                assert chapter_buttons.count() == 4, "四幕按钮未完整出现"
                canvas = page.locator("#scene canvas")
                before = Image.open(io.BytesIO(canvas.screenshot())).convert("RGB")
                bounds = canvas.bounding_box()
                x, y = bounds["x"] + bounds["width"] * .52, bounds["y"] + bounds["height"] * .55
                page.mouse.move(x, y)
                page.mouse.down()
                page.mouse.move(x + 110, y + 25, steps=8)
                page.mouse.up()
                page.wait_for_timeout(120)
                after = Image.open(io.BytesIO(canvas.screenshot())).convert("RGB")
                change = ImageStat.Stat(ImageChops.difference(before, after)).mean
                assert max(change) > 2, "拖动未改变三维画面"
                for index in range(4):
                    button = chapter_buttons.nth(index)
                    button.click()
                    assert button.get_attribute("aria-pressed") == "true", f"第 {index + 1} 幕未切换"
                    assert page.locator("#quoteZh").inner_text().strip(), f"第 {index + 1} 幕没有中文文案"
                    assert page.locator("#quoteEn").inner_text().strip(), f"第 {index + 1} 幕没有英文文案"
                    if chapter_interactions[index] == "light":
                        page.wait_for_timeout(1600)
                        light_before = Image.open(io.BytesIO(canvas.screenshot())).convert("RGB")
                        page.locator("#lightBtn").click()
                        assert page.locator("#lightBtn").get_attribute("aria-pressed") == "true", "光影控件未响应"
                        page.wait_for_timeout(160)
                        light_after = Image.open(io.BytesIO(canvas.screenshot())).convert("RGB")
                        assert max(ImageStat.Stat(ImageChops.difference(light_before, light_after)).mean) > 2, "光影控件未改变画面"
                    if screenshots:
                        page.wait_for_timeout(1600)
                        page.screenshot(path=str(screenshots / f"{name}-act-{index + 1}.png"))
                page.locator("#aboutBtn").click()
                assert page.locator("#aboutDialog").is_visible(), "署名弹层未出现"
                assert page.locator("#photoCredits .credit").count() >= 3, "照片署名未显示"
                page.locator("#closeAbout").click()
                if page.locator("#soundBtn").is_visible():
                    page.locator("#soundBtn").click()
                    page.wait_for_function("document.querySelector('#siteAudio').currentTime > .1", timeout=8000)
                    page.locator("#soundBtn").click()
                page.locator("#exitBtn").click()
                assert page.locator("#intro").is_visible(), "无法返回开篇"
                if errors or outside:
                    raise AssertionError(f"{name}: 页面错误 {errors}；外部请求 {outside}")
                results.append({"viewport": name, "browserErrors": errors, "externalRequests": outside})
                page.close()
            browser.close()
    finally:
        server.shutdown()
        server.server_close()
    return {"browser": True, "views": results}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("site", type=Path)
    parser.add_argument("--browser", action="store_true", help="实际测试桌面与手机浏览器及声音")
    parser.add_argument("--screenshots", type=Path, help="保存验收画面到指定目录")
    args = parser.parse_args()
    root = args.site.resolve()
    report = verify_static(root)
    if report["static"] and args.browser:
        try:
            report.update(verify_browser(root, args.screenshots))
        except Exception as exc:
            report["browser"] = False
            report["errors"].append(f"浏览器验收失败：{exc}")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if report["errors"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
