#!/usr/bin/env python3
"""Inventory user photographs without changing or extracting the originals."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
from pathlib import Path
import tempfile
import zipfile

from PIL import Image, ImageDraw, ImageOps, UnidentifiedImageError

SCHEMA = "pengcheng/photo-audit-v1"
EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".tif", ".tiff", ".bmp"}
Image.MAX_IMAGE_PIXELS = 120_000_000


def candidates(inputs: list[Path], output: Path):
    for supplied in inputs:
        path = supplied.expanduser().resolve()
        if path.is_dir():
            for item in sorted(path.rglob("*")):
                if item.is_symlink() or not item.is_file() or item.suffix.lower() not in EXTENSIONS:
                    continue
                if item.is_relative_to(output):
                    continue
                yield {"container": str(item), "member": None, "source": str(item)}
        elif path.is_file() and zipfile.is_zipfile(path):
            with zipfile.ZipFile(path) as bundle:
                for member in bundle.infolist():
                    name = Path(member.filename)
                    if member.is_dir() or name.suffix.lower() not in EXTENSIONS or "__MACOSX" in name.parts:
                        continue
                    yield {"container": str(path), "member": member.filename,
                           "source": f"{path.name}::{member.filename}"}
        elif path.is_file() and path.suffix.lower() in EXTENSIONS:
            yield {"container": str(path), "member": None, "source": str(path)}
        else:
            raise ValueError(f"不支持的照片输入：{path}")


def read_source(item: dict) -> bytes:
    if item["member"] is None:
        return Path(item["container"]).read_bytes()
    with zipfile.ZipFile(item["container"]) as bundle:
        return bundle.read(item["member"])


def atomic_json(path: Path, payload: dict):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".audit-", suffix=".json", dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as file:
            json.dump(payload, file, ensure_ascii=False, indent=2)
            file.write("\n")
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def contact_sheet(rows: list[tuple[dict, Image.Image]], destination: Path):
    if not rows:
        return
    cell_w, image_h, caption_h, columns = 316, 205, 40, 4
    line_h = image_h + caption_h
    sheet = Image.new("RGB", (columns * cell_w, ((len(rows) + columns - 1) // columns) * line_h), "#e9e7df")
    draw = ImageDraw.Draw(sheet)
    for index, (record, thumbnail) in enumerate(rows):
        x, y = (index % columns) * cell_w, (index // columns) * line_h
        sheet.paste(thumbnail, (x + (cell_w - thumbnail.width) // 2, y + (image_h - thumbnail.height) // 2))
        draw.text((x + 8, y + image_h + 4), f"{record['id']}  {record['width']}x{record['height']}", fill="#27342e")
        duplicate = f"  = {record['duplicateOf']}" if record["duplicateOf"] else ""
        draw.text((x + 8, y + image_h + 22), f"{record['format']}{duplicate}", fill="#64736a")
    temporary = destination.with_suffix(".tmp.jpg")
    sheet.save(temporary, quality=88)
    os.replace(temporary, destination)


def audit(inputs: list[Path], output: Path) -> dict:
    output = output.expanduser().resolve()
    output.mkdir(parents=True, exist_ok=True)
    records, rows, warnings, seen = [], [], [], {}
    for item in candidates(inputs, output):
        try:
            raw = read_source(item)
            digest = hashlib.sha256(raw).hexdigest()
            with Image.open(io.BytesIO(raw)) as opened:
                opened.verify()
            with Image.open(io.BytesIO(raw)) as opened:
                picture = ImageOps.exif_transpose(opened)
                width, height = picture.size
                if min(width, height) < 640:
                    warnings.append(f"{item['source']}：短边低于 640 像素，只宜作细节或缩略展示")
                thumbnail = picture.convert("RGB")
                thumbnail.thumbnail((cell_w := 300, image_h := 194))
                record = {"id": f"p{len(records)+1:03d}", **item, "sha256": digest,
                          "width": width, "height": height, "aspect": round(width / height, 3),
                          "bytes": len(raw), "format": opened.format or Path(item["source"]).suffix.lstrip(".").upper(),
                          "duplicateOf": seen.get(digest), "rights": "【待核实】"}
                seen.setdefault(digest, record["id"])
                records.append(record)
                rows.append((record, thumbnail.copy()))
        except (UnidentifiedImageError, OSError, ValueError, zipfile.BadZipFile) as exc:
            warnings.append(f"{item['source']}：无法读取图像（{exc}）")
    if not records:
        raise ValueError("没有可读取的照片；支持 JPG、PNG、WebP、TIFF、BMP")
    manifest = {"schema": SCHEMA, "inputs": [str(p.expanduser().resolve()) for p in inputs],
                "images": records, "warnings": warnings,
                "note": "来源、作者与许可均须另行核实；本清单不推断授权。"}
    atomic_json(output / "audit.json", manifest)
    contact_sheet(rows, output / "contact-sheet.jpg")
    return manifest


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("inputs", nargs="+", type=Path, help="照片、文件夹或 ZIP，可提供多个")
    parser.add_argument("--out", required=True, type=Path, help="新的审计输出目录")
    args = parser.parse_args()
    result = audit(args.inputs, args.out)
    unique = sum(not row["duplicateOf"] for row in result["images"])
    print(f"已检查 {len(result['images'])} 张，独立图像 {unique} 张；见 {args.out}/audit.json 与 contact-sheet.jpg")
    for warning in result["warnings"]:
        print("警告：", warning)


if __name__ == "__main__":
    main()
