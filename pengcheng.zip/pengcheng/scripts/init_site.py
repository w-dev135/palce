#!/usr/bin/env python3
"""Build a self-contained photographic web project from an audit and a site plan."""

from __future__ import annotations

import argparse
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import sys
import tempfile

from PIL import Image, ImageOps

from audit_photos import read_source

HERE = Path(__file__).resolve().parent
STARTER = HERE.parent / "assets" / "starter"
SITE_SCHEMA = "pengcheng/site-v1"
PLAN_SCHEMA = "pengcheng/plan-v1"
VALID_ID = re.compile(r"^[a-z][a-z0-9_-]*$")
FORBIDDEN = re.compile("|".join(("wat" + "tter", "wat" + r"ter\.cn", r"t\.co/", "wtt" + "-code-animation-studio")), re.I)


def require_text(value: object, name: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f"{name} 必须是非空文字")
    if FORBIDDEN.search(value):
        raise ValueError(f"{name} 含旧作品的推广文字，请重写作品内容")
    return value.strip()


def validate_plan(plan: dict, audit: dict) -> list[tuple[dict, dict]]:
    if plan.get("schema") != PLAN_SCHEMA:
        raise ValueError(f"方案必须使用 {PLAN_SCHEMA}")
    if audit.get("schema") != "pengcheng/photo-audit-v1":
        raise ValueError("照片清单版本不受支持")
    for name in ("titleZh", "titleEn", "introZh", "introEn", "conceptZh", "conceptEn"):
        require_text(plan.get(name), name)
    chapters = plan.get("chapters")
    if not isinstance(chapters, list) or len(chapters) != 4:
        raise ValueError("请提供恰好四幕，并为每幕选择一张真实照片")
    by_id = {item["id"]: item for item in audit["images"]}
    ids, photos, selected = set(), set(), []
    for n, chapter in enumerate(chapters, 1):
        identifier = require_text(chapter.get("id"), f"第 {n} 章 id")
        if not VALID_ID.fullmatch(identifier) or identifier in ids:
            raise ValueError(f"第 {n} 章 id 无效或重复")
        ids.add(identifier)
        photo_id = require_text(chapter.get("photoId"), f"第 {n} 章 photoId")
        photo = by_id.get(photo_id)
        if photo is None or photo.get("duplicateOf"):
            raise ValueError(f"照片 {photo_id} 不在清单中或为重复照片")
        if photo_id in photos:
            raise ValueError(f"照片 {photo_id} 在多个章节重复；请选择不同视角")
        photos.add(photo_id)
        for key in ("labelZh", "labelEn", "quoteZh", "quoteEn"):
            require_text(chapter.get(key), f"第 {n} 章 {key}")
        for key in ("visualEvidence", "spatialAction", "interaction"):
            require_text(chapter.get(key), f"第 {n} 章 {key}")
        credit = chapter.get("credit", {})
        if not isinstance(credit, dict):
            raise ValueError(f"第 {n} 章 credit 必须是对象")
        for key in ("author", "license", "sourceUrl", "changes"):
            if key in credit and not isinstance(credit[key], str):
                raise ValueError(f"第 {n} 章 credit.{key} 必须是文字")
            if FORBIDDEN.search(credit.get(key, "")):
                raise ValueError(f"第 {n} 章 credit.{key} 含旧作品的推广文字")
        selected.append((chapter, photo))
    return selected


def save_display_image(photo: dict, destination: Path) -> str:
    raw = read_source(photo)
    if hashlib.sha256(raw).hexdigest() != photo["sha256"]:
        raise ValueError(f"照片 {photo['id']} 已变化；请重新运行照片审计")
    with Image.open(io.BytesIO(raw)) as original:
        picture = ImageOps.exif_transpose(original)
        picture.thumbnail((2400, 2400), Image.Resampling.LANCZOS)
        if picture.mode != "RGB":
            picture = picture.convert("RGB")
        image_path = destination / "assets" / f"{photo['id']}.jpg"
        picture.save(image_path, "JPEG", quality=85, optimize=True, progressive=True)
    return f"assets/{photo['id']}.jpg"


def build(audit_path: Path, plan_path: Path, output: Path, *, music: bool = True) -> Path:
    audit_path, plan_path, output = audit_path.resolve(), plan_path.resolve(), output.resolve()
    audit = json.loads(audit_path.read_text(encoding="utf-8"))
    plan = json.loads(plan_path.read_text(encoding="utf-8"))
    selected = validate_plan(plan, audit)
    if output.exists():
        raise FileExistsError(f"输出目录已存在，为保护现有作品不覆盖：{output}")
    if not STARTER.is_dir():
        raise FileNotFoundError(f"缺少网页基础工程：{STARTER}")
    output.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix=".pengcheng-", dir=output.parent) as temp:
        stage = Path(temp) / "site"
        shutil.copytree(STARTER, stage)
        (stage / "assets").mkdir(exist_ok=True)
        chapters, credits, credit_lines = [], [], []
        for chapter, photo in selected:
            image = save_display_image(photo, stage)
            chapters.append({key: chapter[key].strip() for key in ("id", "labelZh", "labelEn", "quoteZh", "quoteEn", "interaction")} | {"image": image})
            supplied = chapter.get("credit", {})
            credit = {"image": image, "author": supplied.get("author") or "【待核实】",
                      "license": supplied.get("license") or "【待核实】",
                      "sourceUrl": supplied.get("sourceUrl") or "",
                      "changes": supplied.get("changes") or "缩放与显示格式转换 / resized and converted for display"}
            credits.append(credit)
            credit_lines.append(f"| {photo['id']} | {credit['author']} | {credit['license']} | {credit['sourceUrl'] or '【待核实】'} | {credit['changes']} |")
        audio_file = None
        if music:
            from make_ambient import create as create_ambient
            mood = plan.get("musicMood", "garden")
            created = create_ambient(stage / "assets" / "ambient.mp3", mood=mood)
            audio_file = f"assets/{created.name}"
        site = {"schema": SITE_SCHEMA,
                **{key: plan[key].strip() for key in ("titleZh", "titleEn", "introZh", "introEn")},
                "chapters": chapters, "credits": credits, "audioFile": audio_file}
        (stage / "site.json").write_text(json.dumps(site, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        (stage / "ASSETS.md").write_text(
            "# 摄影素材及署名 / Image credits\n\n"
            "本网页使用照片的缩放副本。原图未被修改。作者、许可、来源待核实的条目，不应视为已获得公开发布授权。\n\n"
            "| ID | 作者 | 许可 | 原页 | 加工 |\n"
            "| --- | --- | --- | --- | --- |\n" + "\n".join(credit_lines) + "\n",
            encoding="utf-8")
        (stage / "RUN.md").write_text(
            "# 预览\n\n在本目录运行 `python3 -m http.server 8766`，浏览器打开 `http://127.0.0.1:8766/`。"
            "需要 HTTP 服务以加载 `site.json`。声音须由访客点击开启。\n\n"
            "画面是照片构成的艺术空间，不是景点测绘复原。发布前核实 `ASSETS.md` 中作者、许可与原页。\n\n"
            "# 发布\n\n将网站 ZIP 解压后，把含有 `index.html` 的文件夹拖入 https://app.netlify.com/drop 。"
            "Netlify 返回地址后，使用手机与电脑检查四幕、音频和照片。打包本身不代表已经上线。\n",
            encoding="utf-8")
        stage.rename(output)
    return output


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--audit", required=True, type=Path, help="audit_photos.py 生成的 audit.json")
    parser.add_argument("--plan", required=True, type=Path, help="景点专属 pengcheng/plan-v1 JSON")
    parser.add_argument("--out", required=True, type=Path, help="尚不存在的网站目录")
    parser.add_argument("--no-music", action="store_true", help="不生成背景音乐")
    args = parser.parse_args()
    try:
        created = build(args.audit, args.plan, args.out, music=not args.no_music)
    except (OSError, ValueError, KeyError) as exc:
        parser.exit(2, f"生成失败：{exc}\n")
    print(f"网页已生成：{created}")


if __name__ == "__main__":
    main()
