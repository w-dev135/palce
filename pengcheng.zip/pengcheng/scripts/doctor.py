#!/usr/bin/env python3
"""Read-only runtime check for a WorkBuddy or Codex workspace."""

from __future__ import annotations

import argparse
import importlib
import json
from pathlib import Path
import shutil
import sys
import tempfile


ROOT = Path(__file__).resolve().parent.parent


def available(module: str) -> bool:
    try:
        importlib.import_module(module)
        return True
    except (ImportError, OSError):
        return False


def diagnose(workspace: Path) -> dict:
    checks: list[dict] = []
    steps: list[str] = []

    def record(name: str, passed: bool, detail: str) -> None:
        checks.append({"id": name, "status": "pass" if passed else "fail", "detail": detail})

    try:
        runtime = json.loads((ROOT / "runtime.json").read_text(encoding="utf-8"))
        config_ok = runtime.get("schema") == "pengcheng/runtime-v1"
        minimum = tuple(runtime["minimum_python"])
    except (OSError, ValueError, KeyError, TypeError):
        config_ok, minimum = False, (3, 11)
    record("runtime", config_ok, "运行配置可读取" if config_ok else "缺少或无法读取 runtime.json")
    if not config_ok:
        steps.append("重新下载完整技能包，确保 SKILL.md 与 runtime.json 位于同一目录。")

    version_ok = sys.version_info[:2] >= minimum
    record("python", version_ok, f"当前 Python {sys.version_info.major}.{sys.version_info.minor}；最低 {minimum[0]}.{minimum[1]}")
    if not version_ok:
        steps.append("准备 Python 3.11 或更高版本，并让 WorkBuddy 使用该解释器。")

    files = ("SKILL.md", "scripts/audit_photos.py", "scripts/init_site.py",
             "assets/starter/index.html", "assets/starter/app.js", "assets/starter/vendor/three.min.js")
    bundle_ok = all((ROOT / name).is_file() for name in files)
    record("bundle", bundle_ok, "技能文件完整" if bundle_ok else "技能文件缺失")
    if not bundle_ok:
        steps.append("重新解压或上传完整的 pengcheng ZIP。")

    workspace = workspace.expanduser().resolve()
    writable = False
    if workspace.is_dir():
        try:
            with tempfile.TemporaryFile(prefix=".pengcheng-check-", dir=workspace) as probe:
                probe.write(b"ok")
                probe.flush()
                probe.seek(0)
                writable = probe.read() == b"ok"
        except OSError:
            pass
    record("workspace", writable, "任务目录可写" if writable else "任务目录不存在或不可写")
    if not writable:
        steps.append("在 WorkBuddy 中选择本人有写入权限的任务目录；不要修改系统目录权限。")

    pillow = available("PIL.Image")
    record("photos", pillow, "Pillow 可读取照片" if pillow else "缺少 Pillow，不能审计和处理照片")
    if not pillow:
        steps.append("在任务项目的独立 Python 环境准备 requirements.txt 中的 Pillow 后重新检查。")

    numpy = available("numpy")
    record("music", numpy, "NumPy 可生成原创配乐" if numpy else "缺少 NumPy，可使用 --no-music 继续生成网页")
    if not numpy:
        steps.append("若需要原创配乐，在任务项目环境准备 requirements.txt 中的 NumPy；否则使用 --no-music。")

    ffmpeg = shutil.which("ffmpeg") is not None
    record("mp3", ffmpeg, "FFmpeg 可编码 MP3" if ffmpeg else "未找到 FFmpeg；配乐会保存为 WAV")

    playwright = available("playwright.sync_api")
    record("browser", playwright, "Playwright 可用于浏览器检查" if playwright else "未找到 Playwright；浏览器验收须另用可用浏览器")

    basic = config_ok and version_ok and bundle_ok and writable and pillow
    capabilities = {"site": basic, "music": basic and numpy,
                    "mp3": basic and numpy and ffmpeg, "browser_script": basic and playwright}
    if not basic:
        status = "blocked"
    elif not (capabilities["music"] and capabilities["mp3"] and capabilities["browser_script"]):
        status = "partial"
    else:
        status = "ready"
    return {"schema": "pengcheng/doctor-v1", "status": status, "checks": checks,
            "capabilities": capabilities, "next_steps": steps}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workspace", required=True, type=Path, help="已有的任务项目目录")
    args = parser.parse_args()
    report = diagnose(args.workspace)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(2 if report["status"] == "blocked" else 0)


if __name__ == "__main__":
    main()
