#!/usr/bin/env python3
"""Create a clean WorkBuddy upload ZIP with a single pengcheng/ top-level folder."""

from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent.parent
REQUIRED = (
    "SKILL.md", "README.md", "LICENSE", "VERSION", "runtime.json",
    "requirements.txt", "requirements-browser.txt", "references/first-use.md",
    "references/plan.md", "references/four-step-workflow.md",
    "references/netlify-drop.md", "scripts/doctor.py", "scripts/audit_photos.py",
    "scripts/init_site.py", "scripts/make_ambient.py", "scripts/verify_site.py",
    "scripts/package_site.py", "assets/starter/index.html", "assets/starter/app.js",
    "assets/starter/style.css", "assets/starter/vendor/three.min.js",
    "assets/starter/vendor/LICENSE",
)
EXCLUDED_PARTS = {"__pycache__", ".git", ".venv", "inputs", "outputs", "agents"}
EXCLUDED_NAMES = {".DS_Store", ".gitignore"}


def package(destination: Path) -> tuple[Path, str, int]:
    destination = destination.expanduser().resolve()
    if destination.exists():
        raise FileExistsError(f"输出包已存在，不覆盖：{destination}")
    if destination.suffix.lower() != ".zip":
        raise ValueError("输出文件必须是 .zip")
    for relative in REQUIRED:
        if not (ROOT / relative).is_file():
            raise FileNotFoundError(f"缺少技能文件：{relative}")
    entry = (ROOT / "SKILL.md").read_text(encoding="utf-8")
    if not entry.startswith("---\n") or "name: pengcheng" not in entry.split("---", 2)[1]:
        raise ValueError("SKILL.md 入口名称不是 pengcheng")
    files = [path for path in sorted(ROOT.rglob("*"))
             if path.is_file() and not path.is_symlink()
             and path.name not in EXCLUDED_NAMES
             and not (set(path.relative_to(ROOT).parts) & EXCLUDED_PARTS)
             and path.suffix.lower() not in {".pyc", ".pyo"}]
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".pengcheng-package-", suffix=".zip", dir=destination.parent)
    os.close(fd)
    try:
        with zipfile.ZipFile(temporary, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=8) as bundle:
            for path in files:
                bundle.write(path, (Path("pengcheng") / path.relative_to(ROOT)).as_posix())
        with zipfile.ZipFile(temporary) as bundle:
            if bundle.testzip() is not None or "pengcheng/SKILL.md" not in bundle.namelist():
                raise ValueError("ZIP 完整性或入口检查失败")
        os.replace(temporary, destination)
    finally:
        Path(temporary).unlink(missing_ok=True)
    digest = hashlib.sha256(destination.read_bytes()).hexdigest()
    (destination.parent / f"{destination.name}.sha256").write_text(
        f"{digest}  {destination.name}\n", encoding="utf-8")
    return destination, digest, len(files)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", required=True, type=Path, help="新的 .zip 路径")
    args = parser.parse_args()
    try:
        path, digest, count = package(args.out)
    except (OSError, ValueError) as exc:
        parser.exit(2, f"封包失败：{exc}\n")
    print(f"WorkBuddy 技能包：{path}\n文件数：{count}\nSHA-256：{digest}")


if __name__ == "__main__":
    main()
