# 四幕方案格式

`init_site.py` 接受 `pengcheng/plan-v1` JSON，必须恰好四幕。每幕 `photoId` 来自 `audit.json` 的不同有效照片。Agent 创建和维护 JSON，用户无需编写。下面句子仅展示结构，正式作品须按照片重写。

```json
{
  "schema": "pengcheng/plan-v1",
  "titleZh": "景点 · 作品题目",
  "titleEn": "LANDMARK · WORK TITLE",
  "introZh": "依据照片写出的场所引言。",
  "introEn": "An introduction grounded in the photographs.",
  "conceptZh": "四幕共同推进的视觉命题。",
  "conceptEn": "The idea developed across four views.",
  "musicMood": "garden",
  "chapters": [
    {"id":"enter","photoId":"p001","labelZh":"入","labelEn":"ENTER","quoteZh":"第一景的短句。","quoteEn":"Line for the first view.","visualEvidence":"照片中的门洞与明暗层次","spatialAction":"从门内缓缓看向门外","interaction":"drag","credit":{"author":"【待核实】","license":"【待核实】","sourceUrl":"","changes":"缩放与网页展示"}},
    {"id":"unfold","photoId":"p002","labelZh":"展","labelEn":"UNFOLD","quoteZh":"第二景的短句。","quoteEn":"Line for the second view.","visualEvidence":"照片中的池面与倒影","spatialAction":"触碰水面，观察倒影变化","interaction":"ripple","credit":{"author":"【待核实】","license":"【待核实】","sourceUrl":"","changes":"缩放与网页展示"}},
    {"id":"turn","photoId":"p003","labelZh":"转","labelEn":"TURN","quoteZh":"第三景的短句。","quoteEn":"Line for the third view.","visualEvidence":"照片中的长廊纵深","spatialAction":"切换晨昏光线","interaction":"light","credit":{"author":"【待核实】","license":"【待核实】","sourceUrl":"","changes":"缩放与网页展示"}},
    {"id":"return","photoId":"p004","labelZh":"返","labelEn":"RETURN","quoteZh":"第四景的短句。","quoteEn":"Line for the final view.","visualEvidence":"照片中的回望视角","spatialAction":"回望入口，完成动线闭环","interaction":"reveal","credit":{"author":"【待核实】","license":"【待核实】","sourceUrl":"","changes":"缩放与网页展示"}}
  ]
}
```

`visualEvidence`、`spatialAction`、`interaction` 是制作意图和验收依据。starter 内置 `drag` 环视与 `light` 基础光线切换；`ripple`、`reveal` 等字段**不会仅凭填写自动产生专题动画**。Agent 必须在网页代码里实现专题动作并实测。照片不含示例中的水或门时，改写意象与交互，不强行套用。`musicMood` 可用 `stone`、`water`、`garden`、`open-air`。

`site.json` 版本为 `pengcheng/site-v1`。每幕保留双语标签和短句，`photoId` 转为本地 `image` 路径。`credits` 列出展示照片；`audioFile` 指向本地原创音乐或为 `null`。`sourceUrl` 只填已核实原页。公开素材清单不应包含用户电脑的原始绝对路径。
