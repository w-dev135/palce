# Netlify Drop 发布

1. 使用 `scripts/package_site.py` 导出网站 ZIP。解压后确认顶层直接有 `index.html`、`site.json`、`assets/` 和 `vendor/`，无需构建命令。
2. 打开 [Netlify Drop](https://app.netlify.com/drop)，登录账号，将**解压后的网站文件夹**拖入页面。若当前界面明确支持 ZIP，也可按界面提示上传 ZIP；以平台实际接受结果为准。
3. 等页面给出 `*.netlify.app` 地址后，分别用电脑和手机打开公开链接，检查入场、四幕、声音、署名和照片加载。随后可以在 Netlify 站点设置中修改站点名；自定义独立域名需拥有该域名并完成 DNS 设置。
4. 不保证固定发布时长或自选域名一定可用。公开发布前核实每张照片的使用许可。交付 ZIP 只证明文件已经准备好，不能代替上传和线上验收。
