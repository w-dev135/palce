# WorkBuddy 首次使用与恢复

本文件供 Agent 执行，不把命令清单交给普通用户。用户发来照片或 ZIP 后，先定位本技能实际安装目录 `<S>`、附件所在路径和当前可写任务项目 `<W>`；不要假定附件仍在下载目录，也不要修改原件。若临时附件可能失效，可只读复制到新建项目的 `inputs/v01/`，保存审计及方案到同一版本目录；成品写到新的 `outputs/v01/`，以后修改用 v02。

查找当前环境可用的 Python 3.11+（例如 `python3`、`python` 或 Windows 的 `py -3`）；记为 `<PY>`。执行 `<PY> <S>/scripts/doctor.py --workspace <W>`。诊断只检查，不安装软件。`status=blocked` 时保留材料，说明缺少的基础能力；不要声称网页已生成。`capabilities.site=true` 可继续。`capabilities.music=false` 时加 `--no-music` 并交付无音乐网页。无 FFmpeg 而有 NumPy 时，脚本保存 WAV；不能把 WAV 称为 MP3。无 Playwright 时可用 WorkBuddy 现有浏览器能力做页面检查；若仍无法打开网页，只报告静态检查结果。

缺 Pillow 或 NumPy 时，可在任务项目的独立 Python 环境按 `requirements.txt` 准备；浏览器脚本依赖见 `requirements-browser.txt`。安装须遵循客户端授权，不能假称 ZIP 自带这些组件。不要把用户带到终端填 JSON：Agent 根据照片、景点名称和可核实来源写 `pengcheng/plan-v1`。若景点身份确实无法判定，先问一个影响设计的问题，同时完成照片审计。

浏览器需要本地 HTTP 服务才能载入 `site.json`。允许启动临时回环服务时运行完整验收；若客户端禁止监听端口，使用其内置预览或说明限制。文件路径含空格和中文时以参数数组传递，避免命令插值。不要把照片、实际用户路径、临时产物或授权记录打入公开 Skill 包。

再次修改时读取上一版的照片审计和方案，建立 v02；保留用户原件、旧成品与已确认署名。若用户手工改过网页，以其提供的最新成品为修改依据。
