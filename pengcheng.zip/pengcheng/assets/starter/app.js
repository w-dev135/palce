/* A configurable photographic space. All text and photographs come from site.json. */
(() => {
  'use strict';
  const $ = (selector) => document.querySelector(selector);
  const reduceMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const narrow = () => innerWidth <= 750;
  const dom = {
    scene: $('#scene'), loading: $('#loading'), fallback: $('#fallback'), intro: $('#intro'),
    experience: $('#experience'), enter: $('#enterBtn'), exit: $('#exitBtn'),
    home: $('#homeBtn'), sound: $('#soundBtn'), light: $('#lightBtn'), audio: $('#siteAudio'),
    about: $('#aboutBtn'), dialog: $('#aboutDialog'), closeAbout: $('#closeAbout'),
    modeList: $('#modeList')
  };
  let data, renderer, scene, camera, pictures = [], particles, started = false;
  let current = 0, transition = null, yaw = .1, pitch = 0, dragging = false;
  let lastX = 0, lastY = 0, priorFocus = null, lastFrame = performance.now();
  const movement = {forward:false, back:false, left:false, right:false};
  let audioContext, audioSource, audioGain, audioPauseTimer;

  function localPath(value) {
    if (typeof value !== 'string' || !value || /^(?:\/|[a-z]+:|\\)/i.test(value) || value.split(/[\\/]/).includes('..')) return null;
    return value;
  }
  function safeSource(value) {
    try { const url = new URL(value); return ['https:', 'http:'].includes(url.protocol) ? url.href : null; }
    catch { return null; }
  }
  function requiredText(value, name) {
    if (typeof value !== 'string' || !value.trim()) throw new Error(`site.json: ${name} is required`);
    return value.trim();
  }
  function validate(input) {
    if (!input || input.schema !== 'pengcheng/site-v1') throw new Error('site.json: unsupported schema');
    for (const key of ['titleZh','titleEn','introZh','introEn']) requiredText(input[key], key);
    if (!Array.isArray(input.chapters) || input.chapters.length !== 4) throw new Error('site.json: provide exactly four chapters');
    const ids = new Set();
    input.chapters.forEach((part, index) => {
      for (const key of ['id','labelZh','labelEn','quoteZh','quoteEn']) requiredText(part[key], `chapters[${index}].${key}`);
      if (!/^[a-z0-9_-]+$/i.test(part.id) || ids.has(part.id)) throw new Error(`site.json: invalid or repeated chapter id ${part.id}`);
      ids.add(part.id);
      if (!localPath(part.image)) throw new Error(`site.json: invalid image path in chapter ${part.id}`);
    });
    if (!Array.isArray(input.credits)) throw new Error('site.json: credits must be an array');
    input.credits.forEach((credit, index) => {
      for (const key of ['image','author','license','sourceUrl','changes']) if (typeof credit[key] !== 'string') throw new Error(`site.json: credits[${index}].${key} must be a string`);
    });
    if (input.audioFile !== null && input.audioFile !== undefined && !localPath(input.audioFile)) throw new Error('site.json: invalid audioFile');
    return input;
  }
  function fillText(selector, value) { $(selector).textContent = value; }
  function populate() {
    document.title = `${data.titleZh} · ${data.titleEn}`;
    document.querySelector('meta[name="description"]').content = `${data.introZh} ${data.introEn}`;
    fillText('#brandZh', data.titleZh); fillText('#brandEn', data.titleEn);
    fillText('#introTitle', data.titleZh); fillText('#introTitleEn', data.titleEn);
    $('#introTitle').classList.toggle('long-title', [...data.titleZh].length > 4);
    $('#introTitle').classList.toggle('very-long-title', [...data.titleZh].length > 7);
    fillText('#introZh', data.introZh); fillText('#introEn', data.introEn);
    fillText('#aboutTitle', `${data.titleZh} / ${data.titleEn}`);
    fillText('#aboutIntroZh', data.introZh); fillText('#aboutIntroEn', data.introEn);
    const credits = $('#photoCredits');
    data.credits.forEach((entry) => {
      const row = document.createElement('div'); row.className = 'credit';
      const title = document.createElement('strong'); title.textContent = `${entry.image} — ${entry.author}`; row.appendChild(title);
      const meta = document.createElement('span'); meta.textContent = `${entry.license} · ${entry.changes}`; row.appendChild(meta);
      const href = safeSource(entry.sourceUrl);
      if (href) { const link = document.createElement('a'); link.href = href; link.target = '_blank'; link.rel = 'noopener noreferrer'; link.textContent = ' 原始来源 ↗ / SOURCE'; row.appendChild(link); }
      credits.appendChild(row);
    });
    dom.modeList.style.setProperty('--chapter-count',String(data.chapters.length));
    data.chapters.forEach((part, index) => {
      const button = document.createElement('button'); button.className = 'mode';
      button.dataset.mode = part.id; button.type = 'button'; button.setAttribute('aria-pressed', 'false');
      const zh = document.createElement('b'); zh.textContent = part.labelZh; button.appendChild(zh);
      const en = document.createElement('small'); en.textContent = part.labelEn; button.appendChild(en);
      button.addEventListener('click', () => selectChapter(index)); dom.modeList.appendChild(button);
    });
    if (data.audioFile) { dom.audio.src = localPath(data.audioFile); dom.sound.hidden = false; }
    selectChapter(0, false);
  }

  function photoTexture(path) {
    return new Promise((resolve) => {
      const loader = new THREE.TextureLoader();
      loader.load(path, texture => { texture.colorSpace = THREE.SRGBColorSpace; texture.anisotropy = 4; resolve(texture); }, undefined, () => resolve(null));
    });
  }
  function proceduralTexture(index) {
    const canvas = document.createElement('canvas'); canvas.width = 768; canvas.height = 512;
    const context = canvas.getContext('2d');
    const palettes = [['#304b57','#a9b9ad'],['#4b5148','#c3af86'],['#343e52','#a3aeb3'],['#504a49','#b7a995'],['#2f4d4c','#96b0a4']];
    const pair = palettes[index % palettes.length]; const grad = context.createLinearGradient(0,0,768,512);
    grad.addColorStop(0,pair[0]); grad.addColorStop(1,pair[1]); context.fillStyle = grad; context.fillRect(0,0,768,512);
    for (let n=0;n<17;n++) { context.strokeStyle = `rgba(230,224,203,${.03 + (n%4)*.018})`; context.lineWidth=1+n%4; context.beginPath(); context.moveTo(n*59-150,0); context.lineTo(n*59+280,512); context.stroke(); }
    const texture = new THREE.CanvasTexture(canvas); texture.colorSpace = THREE.SRGBColorSpace; return texture;
  }
  function addMesh(geometry, material, x=0, y=0, z=0, parent=scene) {
    const object = new THREE.Mesh(geometry,material); object.position.set(x,y,z); parent.add(object); return object;
  }
  function line(x1,y1,z1,x2,y2,z2,color,opacity=.45) {
    const geometry = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(x1,y1,z1),new THREE.Vector3(x2,y2,z2)]);
    const object = new THREE.Line(geometry,new THREE.LineBasicMaterial({color,transparent:true,opacity})); scene.add(object); return object;
  }
  function buildStation(texture, index) {
    const z = -index*7.8, shift = index%2 === 0 ? .95 : -.95;
    const group = new THREE.Group(); group.position.set(shift,0,z); scene.add(group);
    const photo = addMesh(new THREE.PlaneGeometry(7.6,5.1),new THREE.MeshBasicMaterial({map:texture,side:THREE.DoubleSide}),0,0,0,group);
    const edge = new THREE.MeshBasicMaterial({color:0xc9bc9c,transparent:true,opacity:.74});
    addMesh(new THREE.BoxGeometry(7.72,.025,.025),edge,0,2.57,.04,group);
    addMesh(new THREE.BoxGeometry(7.72,.025,.025),edge,0,-2.57,.04,group);
    addMesh(new THREE.BoxGeometry(.025,5.16,.025),edge,-3.86,0,.04,group);
    addMesh(new THREE.BoxGeometry(.025,5.16,.025),edge,3.86,0,.04,group);
    const echo = addMesh(new THREE.PlaneGeometry(4.8,3.2),new THREE.MeshBasicMaterial({map:texture,transparent:true,opacity:.22,side:THREE.DoubleSide,depthWrite:false}),shift>0?-5.45:5.45,.18,2.05,group);
    echo.rotation.y=shift>0?.43:-.43;
    const translucent = addMesh(new THREE.PlaneGeometry(2.1,4.6),new THREE.MeshBasicMaterial({map:texture,transparent:true,opacity:.16,side:THREE.DoubleSide,depthWrite:false}),shift>0?-3.25:3.25,0,3.15,group);
    translucent.rotation.y=shift>0?-.36:.36;
    const metal = new THREE.MeshStandardMaterial({color:0x756e61,roughness:.38,metalness:.68,transparent:true,opacity:.62});
    for (const x of [-6.3,6.3]) {
      addMesh(new THREE.BoxGeometry(.045,6.9,.045),metal,x,0,z+2.6);
      addMesh(new THREE.BoxGeometry(.04,4.3,.04),metal,x*.69,-.75,z+4.1);
    }
    addMesh(new THREE.BoxGeometry(12.7,.035,.04),metal,0,3.4,z+2.6);
    addMesh(new THREE.BoxGeometry(12.7,.035,.04),metal,0,-3.4,z+2.6);
    for (const side of [-1,1]) line(side*5.55,-2.9,z+5.2,side*5.55,-2.9,z-2.1,0xd4b67a,.2);
    const floorPhoto = addMesh(new THREE.PlaneGeometry(7.6,5.1),new THREE.MeshBasicMaterial({map:texture,transparent:true,opacity:.12,side:THREE.DoubleSide,depthWrite:false}),shift,-3.35,z+.1);
    floorPhoto.rotation.x=-Math.PI/2; floorPhoto.scale.y=.8;
    pictures.push({photo,echo,translucent,baseY:group.position.y,group,index});
  }
  function buildParticles() {
    const count = narrow()?190:370, positions = new Float32Array(count*3);
    for (let i=0;i<count;i++) { positions[i*3]=(Math.random()-.5)*15; positions[i*3+1]=(Math.random()-.5)*7; positions[i*3+2]=6-Math.random()*(data.chapters.length*7.8+8); }
    const geometry = new THREE.BufferGeometry(); geometry.setAttribute('position',new THREE.BufferAttribute(positions,3));
    particles = new THREE.Points(geometry,new THREE.PointsMaterial({color:0xe6d8b7,size:.025,transparent:true,opacity:.55,depthWrite:false})); scene.add(particles);
  }
  function cameraFor(index) { return [0,.05,-index*7.8+4.7,index%2===0?.13:-.13,-.015]; }
  function initThree(textures) {
    scene = new THREE.Scene(); scene.background = new THREE.Color(0x17222a); scene.fog = new THREE.FogExp2(0x182730,.022);
    camera = new THREE.PerspectiveCamera(narrow()?68:60,innerWidth/innerHeight,.1,160); camera.rotation.order='YXZ';
    camera.position.set(.4,0,9.7); camera.rotation.y=.1;
    renderer = new THREE.WebGLRenderer({antialias:!narrow(),powerPreference:'high-performance'});
    renderer.setPixelRatio(Math.min(devicePixelRatio,narrow()?1.5:2)); renderer.setSize(innerWidth,innerHeight);
    renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.15;
    dom.scene.appendChild(renderer.domElement);
    scene.add(new THREE.AmbientLight(0xd9e3de,1.75));
    const key = new THREE.DirectionalLight(0xe8dbbd,2.1); key.position.set(-5,7,8); scene.add(key);
    const base = addMesh(new THREE.PlaneGeometry(19,data.chapters.length*7.8+20),new THREE.MeshStandardMaterial({color:0x273237,roughness:.9,metalness:.15}),0,-3.5,-(data.chapters.length-1)*3.9);
    base.rotation.x=-Math.PI/2;
    textures.forEach((texture,index)=>buildStation(texture || proceduralTexture(index),index));
    buildParticles();
    renderer.domElement.addEventListener('pointerdown',pointerDown);
    renderer.domElement.addEventListener('pointermove',pointerMove);
    renderer.domElement.addEventListener('pointerup',pointerUp);
    renderer.domElement.addEventListener('pointercancel',pointerUp);
    renderer.domElement.addEventListener('wheel',wheel,{passive:false});
    addEventListener('resize',resize); addEventListener('keydown',keyboard); addEventListener('keyup',keyboard);
    requestAnimationFrame(tick);
  }
  function selectChapter(index, animate=true) {
    current=index; const part=data.chapters[index], number=String(index+1).padStart(2,'0'), total=String(data.chapters.length).padStart(2,'0');
    setLight(false);
    dom.light.hidden = !started || part.interaction !== 'light';
    fillText('#chapterCount',`${number} / ${total}`); fillText('#chapterLabel',`${part.labelZh} / ${part.labelEn}`);
    fillText('#quoteZh',part.quoteZh); fillText('#quoteEn',part.quoteEn);
    dom.modeList.querySelectorAll('.mode[data-mode]').forEach(button=>{const active=button.dataset.mode===part.id;button.classList.toggle('active',active);button.setAttribute('aria-pressed',String(active));});
    if (started && camera && animate) moveCamera(cameraFor(index),reduceMotion?1:1500);
  }
  function moveCamera(to,duration) { transition={from:[camera.position.x,camera.position.y,camera.position.z,yaw,pitch],to,start:performance.now(),duration}; }
  function enter() { if (!renderer) return; started=true; dom.light.hidden=data.chapters[current].interaction!=='light'; dom.intro.classList.add('dismissed'); dom.experience.classList.remove('hidden'); moveCamera(cameraFor(current),reduceMotion?1:2100); }
  function exit() { started=false; dom.light.hidden=true; setLight(false); dom.intro.classList.remove('dismissed'); dom.experience.classList.add('hidden'); Object.keys(movement).forEach(k=>movement[k]=false); moveCamera([.4,0,9.7,.1,0],reduceMotion?1:1200); }
  function pointerDown(event) { if (!started) return; dragging=true;lastX=event.clientX;lastY=event.clientY;event.currentTarget.setPointerCapture(event.pointerId); }
  function pointerMove(event) { if (!dragging || !started) return;const dx=event.clientX-lastX,dy=event.clientY-lastY;lastX=event.clientX;lastY=event.clientY;transition=null;yaw-=dx*.003;pitch=THREE.MathUtils.clamp(pitch-dy*.003,-.82,.82); }
  function pointerUp() { dragging=false; }
  function wheel(event) { if (!started) return;event.preventDefault();transition=null;camera.position.z=THREE.MathUtils.clamp(camera.position.z+event.deltaY*.008,-(data.chapters.length-1)*7.8+1.5,8.5); }
  function keyboard(event) { const down=event.type==='keydown',key=event.key.toLowerCase(); if (event.key==='Escape' && down) { if (!dom.dialog.classList.contains('hidden')) closeAbout(); else if(started) exit(); } if (!started || !dom.dialog.classList.contains('hidden')) return; const map={w:'forward',arrowup:'forward',s:'back',arrowdown:'back',a:'left',arrowleft:'left',d:'right',arrowright:'right'}; if(map[key]){event.preventDefault();movement[map[key]]=down;} }
  function resize() { if(!renderer)return;camera.aspect=innerWidth/innerHeight;camera.fov=narrow()?68:60;camera.updateProjectionMatrix();renderer.setPixelRatio(Math.min(devicePixelRatio,narrow()?1.5:2));renderer.setSize(innerWidth,innerHeight); }
  function tick(now) {
    requestAnimationFrame(tick); const delta=Math.min(.05,(now-lastFrame)/1000); lastFrame=now;
    if (transition) { const p=Math.min(1,(now-transition.start)/transition.duration),e=p<.5?4*p*p*p:1-Math.pow(-2*p+2,3)/2;const a=transition.from,b=transition.to;camera.position.set(a[0]+(b[0]-a[0])*e,a[1]+(b[1]-a[1])*e,a[2]+(b[2]-a[2])*e);yaw=a[3]+(b[3]-a[3])*e;pitch=a[4]+(b[4]-a[4])*e;if(p===1)transition=null; }
    if(started && !transition) { const f=(movement.forward?1:0)-(movement.back?1:0),s=(movement.right?1:0)-(movement.left?1:0);if(f||s){const speed=(narrow()?2.1:2.9)*delta;camera.position.x+=(-Math.sin(yaw)*f+Math.cos(yaw)*s)*speed;camera.position.z+=(-Math.cos(yaw)*f-Math.sin(yaw)*s)*speed;camera.position.x=THREE.MathUtils.clamp(camera.position.x,-4.2,4.2);camera.position.z=THREE.MathUtils.clamp(camera.position.z,-(data.chapters.length-1)*7.8+1.5,8.5);} }
    camera.rotation.y=yaw;camera.rotation.x=pitch;
    if(!reduceMotion) {const t=now*.00035;pictures.forEach(({group,index})=>{group.position.y=Math.sin(t+index*1.9)*.045;});particles.rotation.y=Math.sin(t*.3)*.008;}
    renderer.render(scene,camera);
  }
  function openAbout() { priorFocus=document.activeElement;dragging=false;Object.keys(movement).forEach(key=>movement[key]=false);dom.dialog.classList.remove('hidden');dom.closeAbout.focus(); }
  function closeAbout() { dom.dialog.classList.add('hidden');(priorFocus||dom.about).focus(); }
  function setLight(on) {
    dom.light.setAttribute('aria-pressed',String(on));
    dom.light.querySelector('small').textContent=on?'DUSK':'SHIFT LIGHT';
    if (!renderer || !scene) return;
    renderer.toneMappingExposure=on?.72:1.15;
    scene.background.setHex(on?0x263547:0x17222a);
    scene.fog.color.setHex(on?0x303c49:0x182730);
  }
  async function setSound(on) {
    if (!data.audioFile) return;
    try {
      clearTimeout(audioPauseTimer);
      if (on) {
        if (!audioContext) {audioContext=new (window.AudioContext||window.webkitAudioContext)();audioSource=audioContext.createMediaElementSource(dom.audio);audioGain=audioContext.createGain();audioGain.gain.value=0;audioSource.connect(audioGain).connect(audioContext.destination);}
        await audioContext.resume(); await dom.audio.play();
        audioGain.gain.cancelScheduledValues(audioContext.currentTime);audioGain.gain.setTargetAtTime(.65,audioContext.currentTime,.6);
      } else if (audioContext) {
        audioGain.gain.cancelScheduledValues(audioContext.currentTime);audioGain.gain.setTargetAtTime(0,audioContext.currentTime,.26);
        audioPauseTimer=setTimeout(()=>dom.audio.pause(),1200);
      }
      dom.sound.setAttribute('aria-pressed',String(on));dom.sound.querySelector('small').textContent=on?'SOUND ON':'SOUND OFF';
    } catch (error) { console.warn('Audio could not be played:',error);dom.sound.setAttribute('aria-pressed','false');dom.sound.querySelector('small').textContent='SOUND OFF'; }
  }
  function bind() {
    addEventListener('blur',()=>{dragging=false;Object.keys(movement).forEach(key=>movement[key]=false);});
    document.addEventListener('visibilitychange',()=>{if(document.hidden){dragging=false;Object.keys(movement).forEach(key=>movement[key]=false);}});
    dom.enter.addEventListener('click',enter);dom.exit.addEventListener('click',exit);dom.home.addEventListener('click',exit);
    dom.about.addEventListener('click',openAbout);dom.closeAbout.addEventListener('click',closeAbout);
    dom.dialog.addEventListener('click',event=>{if(event.target===dom.dialog)closeAbout();});
    dom.dialog.addEventListener('keydown',event=>{if(event.key==='Tab'){const focusables=[...dom.dialog.querySelectorAll('button,a[href]')];const first=focusables[0],last=focusables.at(-1);if(event.shiftKey&&document.activeElement===first){event.preventDefault();last.focus();}else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}}});
    dom.sound.addEventListener('click',()=>setSound(dom.sound.getAttribute('aria-pressed')!=='true'));
    dom.light.addEventListener('click',()=>setLight(dom.light.getAttribute('aria-pressed')!=='true'));
    document.querySelectorAll('[data-walk]').forEach(button=>{const direction=button.dataset.walk;const stop=()=>movement[direction]=false;button.addEventListener('pointerdown',event=>{event.preventDefault();button.setPointerCapture(event.pointerId);movement[direction]=true;});button.addEventListener('pointerup',stop);button.addEventListener('pointercancel',stop);button.addEventListener('lostpointercapture',stop);});
  }
  async function start() {
    bind();
    try {
      const response=await fetch('./site.json',{cache:'no-store'});if(!response.ok)throw new Error(`site.json: HTTP ${response.status}`);
      data=validate(await response.json());populate();
      if(!window.THREE || !document.createElement('canvas').getContext('webgl'))throw new Error('WebGL unavailable');
      const textures=await Promise.all(data.chapters.map(part=>photoTexture(localPath(part.image))));
      initThree(textures);
      dom.loading.classList.add('fade');setTimeout(()=>dom.loading.classList.add('hidden'),750);
    } catch(error) {
      console.error(error);dom.loading.classList.add('hidden');dom.fallback.classList.remove('hidden');
      const detail=document.createElement('span');detail.textContent=error.message;dom.fallback.appendChild(detail);
    }
  }
  start();
})();
