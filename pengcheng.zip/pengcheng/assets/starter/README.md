# pengcheng website starter

This is a static, offline-capable photographic space. It contains no destination imagery, music, referral links, or personal branding. The producer supplies `site.json` and local photos in `assets/`. An optional local audio file can also be placed in `assets/`.

## Configuration

An excerpt of the required `site.json` shape (the finished file needs four distinct chapter objects) is:

```json
{
  "schema": "pengcheng/site-v1",
  "titleZh": "作品中文标题",
  "titleEn": "ENGLISH TITLE",
  "introZh": "中文作品引言。",
  "introEn": "English introduction.",
  "chapters": [
    {
      "id": "chapter-one",
      "labelZh": "章节一",
      "labelEn": "CHAPTER ONE",
      "quoteZh": "与这张照片有关的中文短句。",
      "quoteEn": "An English line related to this photograph.",
      "interaction": "light",
      "image": "assets/photo-one.jpg"
    }
  ],
  "credits": [
    {
      "image": "assets/photo-one.jpg",
      "author": "摄影者姓名",
      "license": "许可或已获授权",
      "sourceUrl": "https://example.org/source",
      "changes": "裁切与缩放"
    }
  ],
  "audioFile": null
}
```

Provide **exactly four chapters**, each with a unique alphanumeric `id` and a local relative image path. `interaction: "light"` displays a basic light switch in the starter; other interaction names are production intent until their behavior is built for that landmark. Supply a credit for every used image, using verified author, license, source and alteration details. If there is no public source URL, use an empty string. Set `audioFile` to a local path such as `assets/ambient.mp3` to show the sound control; keep it `null` when no music is supplied. Audio starts only after a user click. Text is inserted as text, not HTML.

Serve this directory over HTTP, for example `python3 -m http.server 8000`, then open `http://127.0.0.1:8000/`. Opening `index.html` directly from disk will not load `site.json` in most browsers. Check the desktop and phone layouts, all chapters, drag and movement controls, the About panel, photo links and optional audio. `vendor/three.min.js` is a local copy of Three.js; its MIT license is preserved in `vendor/LICENSE`.

Missing images render a procedural visual so the site remains readable, but the delivered work should include every referenced photo. This artistic space is not a measured reconstruction of a real location.
