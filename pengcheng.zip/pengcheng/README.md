# pengcheng

用景点照片创作中英双语、可探索的四幕互动艺术网站的 Skill。Agent 查看照片并标注可见意象，设计景点专属动线和交互，再生成本地网页、照片署名、可选原创配乐和 Netlify Drop 发布包。脚本提供审计和网页起点，具体场景效果由 Agent 实现并验收。Skill 包不包含示例景点照片、用户素材或第三方推广。

## 在 WorkBuddy 中安装

从 GitHub 下载发布页提供的 `pengcheng.zip`，在 WorkBuddy 可用的技能导入界面选择这个 ZIP，并启用。ZIP 内第一层是 `pengcheng/`，其中有 `SKILL.md`。客户端界面可能随版本变化；如果上传入口要求文件夹，先解压并选择 `pengcheng/`。安装后发送类似“用 pengcheng 把这些网师园照片做成四幕互动网站”的自然语言任务，并附照片或 ZIP。首次运行由 Agent 做环境诊断，需要确认的主视觉或素材许可会以自然语言说明。

上传技能仅安装规则和模板。运行环境仍需 Python 3.11+、Pillow；原创配乐需要 NumPy，MP3 编码需要 FFmpeg。需要脚本化桌面/手机验收时，另需 Playwright 和可启动的 Chromium。Agent 会先运行只读诊断；缺 NumPy 可继续生成无音乐网页，缺 FFmpeg 则生成 WAV。组件清单见 `requirements.txt` 与 `requirements-browser.txt`。依赖只应在用户任务项目的独立环境中安装，上传 ZIP 本身不会安装依赖。

## GitHub 仓库布局

将本文件所在的 `pengcheng/` 目录内容放在仓库根目录：`SKILL.md`、`README.md`、`LICENSE`、`runtime.json`、`requirements.txt`、`scripts/`、`references/`、`assets/`。发布下载包可使用 `scripts/package_skill.py` 重新生成。不要上传 `__pycache__`、用户照片、网站输出或本机路径。仓库页面和 ZIP 可分别供阅读源码、下载上传 WorkBuddy。

## 能力与边界

- 输入：本地 JPG、PNG、WebP、TIFF、BMP、照片目录或 ZIP。Agent 完成内部方案 JSON，使用者无需编辑配置。
- 输出：四幕静态网站目录、网站 ZIP、素材清单、验收结果及 [Netlify Drop 指引](references/netlify-drop.md)。网页需要本地 HTTP 服务或静态托管以载入 `site.json`。网站 ZIP 解压后顶层是 `index.html`；将解压后的网站文件夹拖入 Netlify Drop，上传完成后才会得到公开网址。
- 原照片不会被修改；网页是摄影构成的艺术空间，不宣称真实测绘复原。公开发布前逐张核实作者、许可与来源。
- 发布包的本地解压、生成和浏览器结果以随包验收报告为准；WorkBuddy 客户端的实际导入、启用与自然语言调用需在目标版本验收。没有客户端实测前，不将其描述为“安装即用”。照片审计不会自动识别文化意象，Agent 需实际查看照片后作选图判断。

Skill 源码采用 MIT 许可，详见 `LICENSE`。网页模板内含 Three.js，本地副本的 MIT 许可见 `assets/starter/vendor/LICENSE`。用户照片不包含在此许可中。
